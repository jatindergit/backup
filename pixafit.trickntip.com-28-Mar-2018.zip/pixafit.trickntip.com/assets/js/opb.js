/*********************************
 *Define global variables         *
 *********************************/
var COLOR = '#F90404';
document.onkeydown = function (e) {
    return on_keyboard_action(e);
}
document.onkeyup = function (e) {
    return on_keyboardup_action(e);
}

var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var ctrl_pressed = false;

function on_keyboard_action(event) {
    k = event.keyCode;
    //ctrl
    if (k == 17) {
        if (ctrl_pressed == false)
            ctrl_pressed = true;
        if (!window.Clipboard)
            pasteCatcher.focus();
    }
}
function on_keyboardup_action(event) {
    //ctrl
    if (k == 17)
        ctrl_pressed = false;
}


//=== Clipboard ================================================================

//firefox
var pasteCatcher;
if (!window.Clipboard) {
    pasteCatcher = document.createElement("div");
    pasteCatcher.setAttribute("id", "paste_ff");
    pasteCatcher.setAttribute("contenteditable", "");
    pasteCatcher.style.cssText = 'opacity:0;position:fixed;top:1250px;left:0px;';
    pasteCatcher.style.marginLeft = "-20px";
    document.body.appendChild(pasteCatcher);
    pasteCatcher.focus();
    document.addEventListener("click", function () {
        //pasteCatcher.focus();
    });
    document.getElementById('paste_ff').addEventListener('DOMSubtreeModified', function () {

        if (pasteCatcher.children.length == 1) {
            img = pasteCatcher.firstElementChild.src;

            var img2 = new Image();
            img2.onload = function () {
                ctx.drawImage(img2, 0, 0);
            }
            img2.src = img;
            console.log(img);
            setBackgroundImage(img2)
            //ctx.drawImage(img, 0, 0);


            //ctx.drawImage(img, 0, 0);
            //jatinder: don't empty paste catcher
            //pasteCatcher.innerHTML = '';
        }
    }, false);
}
//chrome
window.addEventListener("paste", pasteHandler);
function pasteHandler(e) {
    if (e.clipboardData) {
        var items = e.clipboardData.items;
        if (items) {
            for (var i = 0; i < items.length; i++) {
                if (items[i].type.indexOf("image") !== -1) {
                    var blob = items[i].getAsFile();
                    var URLObj = window.URL || window.webkitURL;
                    var source = URLObj.createObjectURL(blob);
                    paste_createImage(source);
                }
            }
        }
        // If we can't handle clipboard data directly (Firefox),
        // we need to read what was pasted from the contenteditable element
        else {
        }
    } else {
        setTimeout(paste_check_Input, 1);
    }
}
function paste_check_Input() {
    var child = pasteCatcher.childNodes[0];
    pasteCatcher.innerHTML = "";
    if (child) {
        if (cild.tagName === "IMG") {
            paste_createImage(child.src);
        }
    }
}
function paste_createImage(source) {
    var pastedImage = new Image();
    pastedImage.onload = function () {
        ctx.drawImage(pastedImage, 0, 0);
    }
    pastedImage.src = source;
    
    $('#paste_ff').html('<img src="'+source+'" />');
    setBackgroundImage(pastedImage)
}

//=== /Clipboard ===============================================================

//var canvas = new fabric.Canvas('canvas');

var canvas = this.__canvas = new fabric.Canvas('canvas');
canvas.setDimensions({
    width: screen.width,
    height: screen.height
});

//crop canvas
var cropCanvas = this.__canvas = new fabric.Canvas('crop-canvas');
cropCanvas.setDimensions({
    width: screen.width,
    height: screen.height
});
/*Set the backgroud image when paste on document*/
function setBackgroundImage(imgElement) {
    // var f_img = new fabric.Image(src);
    //  var src = 'jail_cell_bars.png';
    //var src = $("#paste_ff img").attr('src'); 
   // var imgInstance = new fabric.Image(imgElement.src, {
   // });
    canvas.setBackgroundImage(imgElement.src, function () {
        canvas.renderAll.bind(canvas);
        
    }, {
        backgroundImageOpacity: 1,
        backgroundImageStretch: false
    });
    
    //set background image to cropCanvas to
    cropCanvas.setBackgroundImage(imgElement.src, function () {
        cropCanvas.renderAll.bind(cropCanvas);
        
    }, {
        backgroundImageOpacity: 1,
        backgroundImageStretch: false
    });

    
    
   
    $("#crop-canvas-bg,#upload-btn").show();


}


function insertImageToBoard() {
    var imgElement = document.getElementById('paste_ff');
    console.log(imgElement);
    var imgInstance = new fabric.Image(imgElement, {
        left: 100,
        top: 100,
        angle: 30,
        opacity: 0.85
    });
    canvas.add(imgInstance);
}

function addRectangle(obj) {
	
	//inactive drawing mode before adding rectangle
   canvas.isDrawingMode = false;
   $('.pencil').removeClass('active-button').text('Pencil');
   
    // create a rectangle with a fill and a different color stroke
    var rect = new fabric.Rect({
        width: 50,
        height: 50,
        radius: 25,
        fill: 'transparent',
        hasBorders: true,
        borderColor: 'red',
        cornerColor: 'green',
        cornerSize: 8,
        transparentCorners: false,
        stroke: COLOR,
        strokeWidth: 4
    });
    canvas.add(rect);
    //canvas.centerObject(rect);
    canvas.renderAll();
    
   
}
function addTextBox(obj) {
	//inactive drawing mode before adding text
   canvas.isDrawingMode = false;
   $('.pencil').removeClass('active-button').text('Pencil');
   
    var text = new fabric.Textbox('Type', {
        width: 200,
        top: 5,
        left: 5,
        fontSize: 17,
        color: COLOR,
        fill: COLOR,
        textAlign: 'left',
        borderColor: 'red',
        cornerColor: 'green',
        fontFamily: 'sans-serif',
        cornerSize: 8,
        transparentCorners: false
    });

    canvas.add(text);
    canvas.centerObject(text);
    canvas.setActiveObject(text);
    text.selectAll();
    text.enterEditing();
    text.hiddenTextarea.focus();
}
function selectPencil(obj) {
    if (canvas.isDrawingMode === false) {
        canvas.isDrawingMode = true;
        $(obj).addClass('active-button').text('Exit Pencil Mode');
        canvas.freeDrawingBrush.color = COLOR;

    } else {
        canvas.isDrawingMode = false;
        $(obj).removeClass('active-button').text('Pencil');
    }

}

function saveImgsaveImg() {
    console.log('export image');
    if (!fabric.Canvas.supports('toDataURL')) {
        alert('This browser doesn\'t provide means to serialize canvas to an image');
    } else {
        window.open(canvas.toDataURL('png'));
    }
}




$("#canvas2png").click(function () {
    canvas.isDrawingMode = false;

    if (!window.localStorage) {
        alert("This function is not supported by your browser.");
        return;
    }
    // to PNG
    window.open(canvas.toDataURL('png'));
});

$('.color-selector table tr td').click(function () {
    $('.color-selector table tr td').removeClass('active-color');
    $(this).addClass('active-color');
    COLOR = $(this).attr('color-code');
    colorChangedCallback();
});
canvas.observe('object:modified', function (e) {
    e.target.resizeToScale();
    canvasUpdated();
});

// customise fabric.Object with a method to resize rather than just scale after tranformation
fabric.Object.prototype.resizeToScale = function () {
    // resizes an object that has been scaled (e.g. by manipulating the handles), setting scale to 1 and recalculating bounding box where necessary
    switch (this.type) {
        case "circle":
            this.radius *= this.scaleX;
            this.scaleX = 1;
            this.scaleY = 1;
            break;
        case "ellipse":
            this.rx *= this.scaleX;
            this.ry *= this.scaleY;
            this.width = this.rx * 2;
            this.height = this.ry * 2;
            this.scaleX = 1;
            this.scaleY = 1;
            break;
        case "polygon":
        case "polyline":
            var points = this.get('points');
            for (var i = 0; i < points.length; i++) {
                var p = points[i];
                p.x *= this.scaleX
                p.y *= this.scaleY;
            }
            this.scaleX = 1;
            this.scaleY = 1;
            this.width = this.getBoundingBox().width;
            this.height = this.getBoundingBox().height;
            break;
        case "triangle":
        case "line":
        case "rect":
            this.width *= this.scaleX;
            this.height *= this.scaleY;
            this.scaleX = 1;
            this.scaleY = 1;
        default:
            break;
    }
}

function deleteObject() {
    var activeObject = canvas.getActiveObject(),
            activeGroup = canvas.getActiveGroup();
    if (activeObject) {

        canvas.remove(activeObject);

    } else if (activeGroup) {

        var objectsInGroup = activeGroup.getObjects();
        canvas.discardActiveGroup();
        objectsInGroup.forEach(function (object) {
            canvas.remove(object);
        });

    }
}
function startNew() {
    window.location.reload();
}

function upload() {
    $.ajax({
        url: CFG.url + 'upload', // this is the object instantiated in wp_localize_script function
        type: 'POST',
        //contentType: "application/upload",
        contentType: "application/x-www-form-urlencoded",
        data: {
				action: 'save_screen', 
				screen: canvas.toDataURL('image/png')
			},
        dataType: 'json',
        success: function (data) {
            console.log(data);
            if (data.error) {
                $('#share_url').text(data.message);
            } else {
                $('#share_url').text(data.share_url);
            }

            $("#upload-btn").hide();
            $("#clipboard-btn").show();

        },
        error: function (jqXHR, textStatus, errorThrown) {

        },
        beforeSend: function (jqXHR, settings) {
			$("#upload-btn,#clipboard-btn").hide();
            //$("#upload-btn").addClass('btn-loader-ajax');
            $("#progress-wrp").removeClass('force-display-hide');
        },
        complete: function (jqXHR, textStatus) {
            $("#progress-wrp").addClass('force-display-hide');
        },
        xhr: function(){
			//upload Progress
			var xhr = $.ajaxSettings.xhr();
			if (xhr.upload) {
				xhr.upload.addEventListener('progress', function(event) {
					var percent = 0;
					var position = event.loaded || event.position;
					var total = event.total;
					if (event.lengthComputable) {
						percent = Math.ceil(position / total * 100);
					}
					console.log(percent);
					//update progressbar
					$("#progress-wrp .progress-bar").css("width", + percent +"%");
					$("#progress-wrp .status").text(percent +"%");
				}, true);
			}
			return xhr;
		}
    });

}

//callbacks
function canvasUpdated()
{
    $("#upload-btn").show();
}

function colorChangedCallback() {
    canvas.freeDrawingBrush.color = COLOR;
}



function copyText(text) {
    function selectElementText(element) {
        if (document.selection) {
            var range = document.body.createTextRange();
            range.moveToElementText(element);
            range.select();
        } else if (window.getSelection) {
            var range = document.createRange();
            range.selectNode(element);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
        }
    }
    var element = document.createElement('DIV');
    element.textContent = text;
    document.body.appendChild(element);
    selectElementText(element);
    document.execCommand('copy');
    element.remove();
}


var txt = document.getElementById('share_url');
var btn = document.getElementById('clipboard-btn');
btn.addEventListener('click', function () {
    copyText(txt.innerHTML);
    btn.innerHTML = 'Copied!';
})


$(document).keypress(function (e) {
    if (e.which == 0 || e.which == 127) {

        deleteObject();

    }
});



/*
 * 
 * resize canvas background image
 */
/*function resizeCanvasBackgroundImage() {
    console.log('window.width:' + $(window).width())
    console.log('window.height:' + $(window).height())
    canvas.backgroundImage.scaleToWidth($(window).width());
     canvas.backgroundImage.scaleToHeight(screen.height);
    canvas.renderAll();
}*/
function cropCanvasBG() {
    $('img#cropbox').attr('src', $('#paste_ff img').attr('src'));
    $('#cropbox').Jcrop({
        //minSize: [50, 50],
        setSelect:   [ 50, 50, 700, 700 ],
        boxWidth: $(window).width()-80,
        boxHeight: $(window).height()-80,
        onSelect: updateCoords
    });



    $('#jc-container').show();
}

function updateCoords(c) {

    //console.log(c)

    imgs = cropCanvas.toDataURL({
        format: 'png',
        left: c.x,
        top: c.y,
        width: c.w,
        height: c.h
    });

    $('img#crop-result').attr('src', imgs);
    //console.log(imgs)
}

function removeCanvasBackgroundImage() { 
    canvas.backgroundImage = 0;
    canvas.backgroundColor = '#FFF';
    canvas.renderAll();
}
/*
 * 
 * resize canvas
 */
function resizeCanvasToFitBackground() {
    canvas.setDimensions({
        width: canvas.backgroundImage.width,
        height: canvas.backgroundImage.height
    });
    canvas.renderAll();
}

function confirmCrop() {
	removeCanvasBackgroundImage();
	canvas.setBackgroundImage($('img#crop-result').attr('src'), function() {
      canvas.renderAll();
      resizeCanvasToFitBackground()
    });
    $('#jc-container').hide();
}

function cancelCrop() {
    $('#jc-container').hide();
}
