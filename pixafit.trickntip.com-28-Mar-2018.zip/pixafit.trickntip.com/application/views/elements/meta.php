<?php
/*
 * Check if screen need to share on media
 */
$og_image = base_url() . 'assets/images/online-pasteboard.png';

/*
 * Screen url or page url to share
 */
$og_url = base_url();

if (!empty($id)) {
	$og_image = base_url() . 'assets/uploads/' . $id.'.png';
	$og_url = base_url() . 's/' . $id;
	
}
?>
<meta property="og:url" content="<?php echo $og_url; ?>"/>
<meta property="og:image" content="<?php echo $og_image; ?>" />

