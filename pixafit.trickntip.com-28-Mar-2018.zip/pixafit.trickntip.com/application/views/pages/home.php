
	<h1>Home</h1>

	<div id="body">
		<p>We are always eager to create online web tools that can assist you in web development. We have created many tools so far and started the main technical blog.</p>
		
		<p>Share Bild is a quick online tool that is developed using HTML5 and fabricjs library.</p>

		<p>This tool will reduce the need to install any application on system to share the screen shot and make minor modifications.</p>
	
		<p>All images created in this will be shared online and can be access with the very short link.</p>
	
	</div>
	
	<!-- banner add -->
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<ins class="adsbygoogle"
		 style="display:block"
		 data-ad-client="ca-pub-8039939772435746"
		 data-ad-slot="4095716514"
		 data-ad-format="auto"></ins>
	<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
	<!-- .banner add -->

	
