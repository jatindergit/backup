<?php add_css(array('jquery.Jcrop.css'));?>
<?php add_js(array('jquery-3.1.1.min.js','jquery.Jcrop.js','fabric.js'));?>

<header class="site-header" role="banner">
	<div class="pull-left">
		<h1>Pixafit</h1>
	</div>
	<div class="pull-right" id="top-nav">
		<ul>
			<li><?php echo anchor('help','Help',array('title' => 'Help'));?></li>
			<li>
				<a target="_blank" href="<?php echo 'https://www.facebook.com/sharer/sharer.php?u='.base_url(); ?>">Share Us On Facebook</a>
			</li>
		</ul>
	</div>
	<div class="clear"></div>
</header><!-- .page-header -->

	
	<div class="sb-tools">
		<button class="button plus" title="Start Creating New Image" onclick="startNew()">New</button>
		<button class="button rectangle" title="Insert Rectangle" onclick="addRectangle(this)">Rectangle</button>
		<button class="button type-text" title="Add Text" onclick="addTextBox(this)">Text</button>
		<button class="button pencil" title="Use Pencil" onclick="selectPencil(this)">Pencil</button>
		<div class="color-selector">
			<table>
				<tr>
					<td color-code="#f90404" class="red-bg">&nbsp;</td>
					<td color-code="#00f258" class="green-bg">&nbsp;</td>
					<td color-code="#000000" class="black-bg">&nbsp;</td>
				</tr>
			</table>
		</div>
		
		<button title="Crop Image" class="display-hide button crop" id="crop-canvas-bg" onclick="cropCanvasBG(this)">Crop</button>
		
		<button title="Upload Image On Server" class="display-hide button upload" id="upload-btn" onclick="upload()">Upload</button>		
		
		<span class="display-hide" id="share_url"></span>
		
		<button id="clipboard-btn" title="Copy Share Link" class="button copy display-hide">Copy Share Link</button>
		
		<div class="force-display-hide" id="progress-wrp"><div class="progress-bar"></div><span class="status">0%</span></div>
				
	</div>
	<div class="can-area-container">
		<canvas id="canvas" width="1510" height="820"></canvas>  
	</div>
	
	<!--jcorp-->
        <div id="jc-container" class="display-hide">
            <div class="jc-controls">
                <button class="button tick" onclick="confirmCrop(this)">Confirm</button>
                <button class="button cross" onclick="cancelCrop(this)">Cancel</button>
            </div>
            <!-- This is the image we're attaching Jcrop to -->
            <img src="" id="cropbox" />
            
            <!--keep the following elements hide-->
            <img class="display-hide" src="" id="crop-result" />
            <div class="display-hide">
				<canvas id="crop-canvas"></canvas>
            </div>
        </div>
        
        
        <!-- load custom js-->
        
        <script type='text/javascript'>
        var OPB = {
			ajax_url: 'upload'
		};
        
        </script>
        
        <script type="text/javascript">
			var CFG = {
				url: '<?php echo $this->config->item('base_url');?>',
				token: '<?php echo $this->security->get_csrf_hash();?>'
			};
		</script>
		
	<script type='text/javascript' src="<?php echo base_url(); ?>assets/js/opb.js"></script>
	<!-- //load custom js -->


	<div style="width:100%;height:140px; margin-top:10px; text-align:center;">
		<!-- banner add -->
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
		<ins class="adsbygoogle"
			 style="display:block"
			 data-ad-client="ca-pub-8039939772435746"
			 data-ad-slot="4095716514"
			 data-ad-format="auto"></ins>
		<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
		<!-- .banner add -->
	</div>

	
