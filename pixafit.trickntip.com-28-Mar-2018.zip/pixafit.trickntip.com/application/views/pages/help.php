<header class="site-header" role="banner">
	<div class="pull-left">
		<h1>Pixafit</h1>
	</div>
	<div class="pull-right" id="top-nav">
		<ul>
			<li><a href="<?php echo base_url(); ?>">Create</a></li>
			<li><?php echo anchor('help','Help',array('title' => 'Help'));?></li>
			<li>
				<a target="_blank" href="<?php echo 'https://www.facebook.com/sharer/sharer.php?u='.base_url(); ?>">Share Us On Facebook</a>
			</li>
		</ul>
	</div>
	<div class="clear"></div>
</header><!-- .page-header -->

	<h2>Guide</h2>
	
	<div id="body">
		<p class="intro">Share Bild is a quick online tool that is developed using HTML5 and fabricjs library. This tool will reduce the need to install any application on system to share the screen shot and make minor modifications. All images created in this will be shared online and can be access with the very short link. </p>
		<ol>
			<li>
				You must have some image in your system clipboard. You can use Print Screen button to print entire screen. 
			</li>
			<li>
				Now open <?php echo anchor('create','Pixafit', array('target' => '_BLANK'));?> and press CTRL + v to paste the data that you have in your system clipboard.
			</li>
			<li>
				Wow! you will see now your screen has been saved in canvas and ready to start editing or even crop before making your online illustration.
			</li>
		</ol>
	</div>
		<div style="width:100%;height:140px;text-align:center;">
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- Automatic size -->
	<ins class="adsbygoogle"
		 style="display:block"
		 data-ad-client="ca-pub-8039939772435746"
		 data-ad-slot="3956115712"
		 data-ad-format="auto"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
	
	</div>

