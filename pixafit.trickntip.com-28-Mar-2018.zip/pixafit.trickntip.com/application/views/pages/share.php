<?php add_css(array('bootstrap.min.css'));?>
<?php add_js(array('jquery-3.1.1.min.js','bootstrap.min.js'));?>
<header class="site-header" role="banner">
	<div class="pull-left">
		<h1>Pixafit</h1>
	</div>
	<div class="pull-right" id="top-nav">
		<ul>
			<li><a href="<?php echo base_url(); ?>">Create</a></li>
			<li><a href="javascript:void(0);">Details</a></li>
			<li>
				<a data-toggle="modal" data-target="#share-model" href="javascript:void(0);">Share</a>
			</li>
		</ul>
	</div>
	<div class="clear"></div>
</header><!-- .page-header -->
	<?php $share_url = base_url() . 's/' . $id; ?>
	<?php $image_url = base_url() . 'assets/uploads/' . $id.'.png'; ?>
	<?php $image_path = FCPATH. 'assets/uploads/' . $id.'.png'; ?>
	<div class="display-screen">
		<a title="Click To Open" target="_BLANK" href="<?php echo $image_url; ?>">
			<img src="<?php echo $image_url; ?>" alt="Loading..." />
		</a>
	</div>
	<div class="display-hide share-details">
		<div class="content-thumb">
			<img width="100" src="<?php echo $image_url; ?>" alt="Loading..." />
		</div>	
		<div class="content-created-at"><?php echo date ('F d Y h:i A', filemtime($image_path));?></div>
		<div class="content-size"><?php echo round(filesize($image_path)/1024,2);?> KB</div>
	</div>
	<div style="width:100%;height:140px;text-align:center;">
	<!--	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

	<ins class="adsbygoogle"
		 style="display:inline-block;width:300px;height:300px"
		 data-ad-client="ca-pub-8039939772435746"
		 data-ad-slot="3956115712"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>-->
	
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- Automatic size -->
	<ins class="adsbygoogle"
		 style="display:block"
		 data-ad-client="ca-pub-8039939772435746"
		 data-ad-slot="3956115712"
		 data-ad-format="auto"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
	
	</div>

	<!-- Modal -->
	<div class="modal fade" id="share-model" tabindex="-1" role="dialog" aria-labelledby="share-model" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h2 class="modal-title pull-left">Share</h2>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <div class="modal-body">
			  <form class="">
				<fieldset>
				<!-- Share on Social Media -->
				<div class="row">
					<div class="col-sm-12 form-group">
					<a class="btn btn-primary" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $share_url;?>">Share on Facebook</a>
					</div>	
				</div>
				<!-- Text input-->
				<div class="row">
					<div class="col-sm-12 form-group">
						<label>Share URL</label>  	
						<input class="form-control input-md" type="text" onclick="this.focus();this.select()" readonly="" value="<?php echo $share_url;?>">	
					</div>
				</div>

				<!-- Textarea -->
				<div class="row">                     
					<div class="col-sm-12 form-group">
					<label>Embed Code</label>
				  
					<textarea class="form-control" onclick="this.focus();this.select()" readonly="">&lt;!-- copy and paste. Modify height and width if desired. --&gt; &lt;a href="<?php echo $image_url;?>"&gt;&lt;img class="embeddedObject" src="<?php echo $image_url;?>" border="0" /&gt;&lt;/a&gt;</textarea>
				  </div>
				</div>

				</fieldset>
			</form>

			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  </div>
		</div>
	  </div>
	</div>
	
	
	
