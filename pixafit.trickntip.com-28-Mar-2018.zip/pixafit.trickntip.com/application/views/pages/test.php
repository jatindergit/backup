<form method="post" action=''>
<input name='name'>
<input type="submit"/>
</form>
