<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({
                google_ad_client: "ca-pub-8039939772435746",
                enable_page_level_ads: true
            });
    </script>
	<meta charset="utf-8">
	<title><?php echo isset($title) ? $title : 'Online Pasteboard' ;?> - <?php echo SITE_NAME ?></title>
	
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Online pasteboard is tool that is created using HTML 5 and Fabric JS library similar like screencast. You can easily upload your image on server and share the link with others.">
	
	<meta name="keywords" content="Online Editing, online pasteboard, pasteboard, image editing, edit image, fabric js, fabric.js, canvas, canvas tools, online share image, online sharing">
	
	<!--load plugins css-->
	<?php add_css(array('style.css'));?>
	<?php echo render_style();?>
	<!--//load plugins css-->
	
	<!--load plugins js-->
	
	<?php echo render_script();?>
  
	<!--load plugins js-->
	
	
	
	<!--google analytics -->
	<script type="text/javascript">
            window.google_analytics_uacct = "UA-88470011-1";
        </script>

        <script type="text/javascript">
            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-88470011-1']);
            _gaq.push(['_trackPageview']);

            (function () {
                var ga = document.createElement('script');
                ga.type = 'text/javascript';
                ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(ga, s);
            })();
        </script>
    <!--//google analytics -->    
    
    <!--Set meta to share on social sites-->
    <meta property="og:title" content="Online Pasteboard - Pixafit"/>
	<meta property="og:type" content="website"/>
	<?php echo isset($meta) ? $meta : '' ;?>
	<meta property="og:image:width" content="224" />
	<meta property="og:image:height" content="224" />
	<meta property="og:site_name" content=""/>
	<meta property="og:description"	content="Online pasteboard is tool that is created using HTML 5 and Fabric JS library similar like screencast. You can easily upload your image on server and share the link with others."/>
	<!--//Set meta to share on social sites-->
	
</head>
<body>

<div id="container">
	<div id="content">
	<?php echo $content;?>
	</div>
</div>



</body>
</html>
