<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		
        parent::__construct();
		
		$this->load->helper('url');
		
	} 
	 
	public function index()
	{
		$data = array();
		
		$data['meta'] = $this->load->view('elements/meta', $data , TRUE);
		
		$data['content'] = $this->load->view('pages/create', $data, TRUE);
        
        $this->load->view('layouts/default', $data);
	}
	
	
	public function share($id){
		
		$data = array();
		
		$data['title'] = 'View Image';
		
		$data['id'] = $id;
		
		$data['meta'] = $this->load->view('elements/meta', $data , TRUE);
		
		
		
		$data['content'] = $this->load->view('pages/share', $data, TRUE);
        
        $this->load->view('layouts/default', $data);
	}
	
	public function help(){
		
		$data = array();
		
		$data['title'] = 'Guide';
		
		$data['content'] = $this->load->view('pages/help', $data, TRUE);
        
        $this->load->view('layouts/default', $data);
		
	}
	
	public function home(){
		
		$data = array();
		
		$data['title'] = 'Home';
		
		$data['content'] = $this->load->view('pages/home', $data, TRUE);
        
        $this->load->view('layouts/default', $data);
		
	}
	
	public function upload(){
		//print_r($_POST);
		if ($this->input->is_ajax_request()){
			ini_set('upload_max_filesize','10M');
			ini_set('post_max_size','10M');
			$imageData = $this->input->post('screen');
			$filteredData=substr($imageData, strpos($imageData, ",")+1);
			//list($type, $data) = explode(';', $data);
			$data = base64_decode($filteredData);
			$siteURL = base_url();
			$id = uniqid();
			$name = $id . '.png';
			$path = ((dirname(dirname(dirname(__FILE__))))) . '/assets/uploads/' . $name;
			$response = array('error' => 1, 'message' => 'We are bit overloaded. Please try later');
			//var_dump(file_put_contents($path, $data));
			//$file = fopen($path, "w+");
			//fwrite($data, $file);
			//fclose($file);
			if (file_put_contents($path, $data)) {
				$response = array('error' => 0, 'url' => $siteURL, 'name' => $name, 'share_url' => $siteURL . 's/' . $id);
			}
			echo json_encode($response);
		}
		exit;
	}
	
}
